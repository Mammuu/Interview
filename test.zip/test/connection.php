<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = ""; // Assuming no password for localhost
$dbname = "student";

// Create connection
$con = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if ($con) {
    echo "ok";
}
else
{
    echo "DB Not Connected";
}
?>