<?php include 'connection.php'; ?>
<table border ="1px" cellpadding= "10px" cellspacing="0">

  <tr>
    <th>Name</th>
    <th>Class</th>
    <th>Photo</th>
    <th>Video</th>
   

    <td>
      <button>Edit</button>
      <button class="delete">Delete</button>
   </td>
   <?php
     $query="SELECT *  FROM student_table";
     $data=mysqli_query($con,$query);
     $result=mysqli_num_rows($data);
     if($result) {
        
        while($row=mysqli_fetch_array($data)) {
            ?>
        
        <tr>
            <td><?php echo $row ['name']; ?>
            </td>
            <td><?php echo $row ['class']; ?>
            </td>
            <td><?php echo $row ['photo']; ?>
            </td>
            <td><?php echo $row ['video']; ?>
            </td>
            <td>
          </tr>
            <?php
        }
    }
    else
    {
        
      ?>
    <tr>
  <td>No Record Found</td>
  </tr>
<?php
    }
?>
