<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Book and Class Information Forms</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      display: flex;
      justify-content: space-around;
      flex-wrap: wrap; /* Allow items to wrap to the next line */
    }
    .form-container {
      max-width: 400px;
      margin: 10px; 
      padding: 20px;
      border: 2px solid #ccc;
      border-radius: 10px;
    }
    .form-group {
      margin-bottom: 16px;
      display: flex;
      align-items: center;
    }
    .form-group label {
      flex: 1;
      margin-right: 10px;
    }
    .form-group input,
    .form-group select {
      flex: 2;
      padding: 8px;
      box-sizing: border-box;
    }
    button {
      background-color: #4caf50;
      color: white;
      padding: 10px 15px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
    button.cancel {
      background-color: #f44336;
    }

    table {
      border-collapse: collapse;
      width: 100%;
      margin: 10px;
    }

    th, td {
      border: 1px solid #ddd;
      padding: 8px;
    }

    th {
      background-color: #f2f2f2;
    }

    button.delete {
      background-color: #f44336;
      color: white;
    }
  </style>
</head>
<body>

  <div class="form-container">
    <form action="db.php" method="post" enctype="multipart/form-data">
      <div class="form-group">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>
      </div>
  
      <div class="form-group">
        <label for="class">Class:</label>
        <input type="text" id="class" name="class" required>
      </div>
  
      <div class="form-group">
        <label for="photos">Photos:</label>
        <input type="file" id="photos" name="photos" accept="image/*" required>
      </div>
  
      <div class="form-group">
        <label for="videos">Videos:</label>
        <input type="file" id="videos" name="videos" accept="video/*" required>
      </div>
  
      <hr>
      <button type="submit">save</button>
      <button type="button" class="cancel">Cancel</button>
    </form>
  </div>

  <div class="form-container">
    <form action="db2.php" method="post" enctype="multipart/form-data">
      <div class="form-group">
        <label for="Name"> name:</label>
        <input type="text" id="name" name="name" required>
      </div>
  
      <div class="form-group">
        <label for="author">author:</label>
        <input type="text" id="author" name="author" required>
      </div>
  
      <div class="form-group">
        <label for="publication">Publication:</label>
        <input type="text" id="publication" name="publication" required>
      </div>
  
      <div class="form-group">
        <label for="year">Year:</label>
        <input type="text" id="year" name="year" required>
      </div>
  
      <hr>
  
      <button type="submit">save</button>
      <button type="button" class="cancel">Cancel</button>
    </form>
  </div>
  ?php include 'connection.php'; ?>
<table border ="1px" cellpadding= "10px" cellspacing="0">

<tr>
    <th>StudentName</th>
    <th>BookName</th>
    <th>StartDate</th>
    <th>EndDate</th>
    <th>   
    <input type="submit" name= "save_btn"
         value= "save"> 
      <button type="button" class="cancel">Cancel</button></th>
  </tr>

  <?php
     $query="SELECT *  FROM mydb";
     $data=mysqli_query($con,$query);
     $result=mysqli_num_rows($data);
     if($result) {
        
        while($row=mysqli_fetch_array($data)) {
            ?>
        
        <tr>
            <td><?php echo $row ['studentname']; ?>
            </td>
            <td><?php echo $row ['bookname']; ?>
            </td>
            <td><?php echo $row ['startdate']; ?>
            </td>
            <td><?php echo $row ['enddate']; ?>
            </td>
            <td>
          </tr>
            <?php
        }
    }
    else
    {
        ?>
        <tr>
      <td>No Record Found</td>
    </tr>
    <?php

    }
    ?>

         
    
     
</body>
</html>